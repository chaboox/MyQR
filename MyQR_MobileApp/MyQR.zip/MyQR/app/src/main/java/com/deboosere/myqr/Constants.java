package com.deboosere.myqr;

public class Constants {
    final public static int INFINITE_LOOPS = -1;
    final public static int ONE_LOOP = 0;
    final public static int TWO_LOOPS = 1;
    public static final int POPULATE = 100;
    public static final int UPDATE = 101;

    public static final String USERCODE = "chaboox@gmail!?!com";
}
