package com.deboosere.myqr.base;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by GongWen on 17/8/24.
 */

public class BaseActivity extends AppCompatActivity {
}
