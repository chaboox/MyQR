package com.deboosere.myqr;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


public class MyScansFragment extends android.support.v4.app.Fragment {

    private ListView listView;
    private SwipeRefreshLayout swipeLayout;
    private ArrayList<UserModel> userModels;
    private CustomContactAdapter adapter;
    public static Handler handler;

    public static MyScansFragment newInstance(String title) {
        MyScansFragment testFragment = new MyScansFragment();

        return testFragment;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_scans_fragment, container, false);

        initView(view);
        registerForContextMenu(listView);
        getFirebaseData();

        return view;
    }

    private void getFirebaseData() {
        new FirebaseManager().getMyScanUsers(userModels);
    }

    private void populateListView() {
        adapter = new CustomContactAdapter(userModels, getContext());
        listView.setAdapter(adapter );
    }

    private void initView(View view) {
        swipeLayout = view.findViewById(R.id.swipe_container);
        swipeLayout.setColorScheme(android.R.color.holo_blue_dark,
                android.R.color.holo_green_light);
        listView = view.findViewById(R.id.list_my_scan);
        userModels = new ArrayList<>();
        handler = new HandlerMyScan();

    }

    public class HandlerMyScan extends Handler{
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case Constants.POPULATE:
                    populateListView();
                    break;
                case Constants.UPDATE:
                    userModels = new ArrayList<>();
                    //populateListView();
                    break;
            }
        }
    }
}
